-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2024 at 01:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fos_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(30) NOT NULL,
  `client_ip` varchar(20) NOT NULL,
  `user_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `name`) VALUES
(1, 'Breakfast'),
(2, 'Lunch'),
(3, 'Dinner'),
(4, 'Liquid Lounge');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` varchar(11) NOT NULL,
  `mobile` text NOT NULL,
  `email` text NOT NULL,
  `table_number` int(11) NOT NULL,
  `status` tinyint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `address`, `mobile`, `email`, `table_number`, `status`) VALUES
(43, 'PRITI KUMARI', 'Telco', '8092329205', 'pritiroy611@gmail.com', 1, 1),
(44, 'PRITI KUMARI', 'Telco', '8092329205', 'pritiroy611@gmail.com', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `product_id`, `qty`) VALUES
(40, 38, 10, 1),
(41, 42, 15, 1),
(42, 43, 14, 1),
(43, 44, 17, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `img_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0= unavailable, 2 Available',
  `category` enum('Breakfast','Lunch','Dinner','Liquid Lounge') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `category_id`, `name`, `description`, `price`, `img_path`, `status`, `category`) VALUES
(1, 0, 'Diet Coke', 'In Can', 20, '1600652160_diet_coke.jpg', 1, 'Liquid Lounge'),
(3, 0, 'Lemon Iced Tea', '', 15, '1600652520_lemon iced tea.jpg', 0, 'Liquid Lounge'),
(4, 0, 'Chicken', '', 150, '1600652880_chicken.jpg', 1, 'Lunch'),
(8, 0, 'Rice', 'Plain rice', 25, '1720491960_rice.jpeg', 1, 'Lunch'),
(9, 0, 'Chicken Biryani', '', 120, '1720492080_biryani.jpeg', 0, 'Lunch'),
(10, 0, 'Dosa', '', 70, '1720492140_dosa.jpg', 1, 'Breakfast'),
(11, 0, 'Dal', '', 60, '1720493640_dal.jpg', 1, 'Dinner'),
(12, 0, 'Fried Rice', '', 70, '1720493700_fried rice.jpg', 1, 'Dinner'),
(13, 0, 'Aloo Paratha', '', 20, '1721106600_aloo paratha.jpg', 1, 'Breakfast'),
(14, 0, 'Upma', '', 15, '1721106660_upma.jpg', 1, 'Breakfast'),
(15, 0, 'Poha', '', 15, '1721106660_poha.jpg', 1, 'Breakfast'),
(16, 0, 'Pulaw', '', 60, '1721106720_pulaw.jpg', 1, 'Lunch'),
(17, 0, 'Tadka', '', 40, '1721106840_dal tadka.jpg', 1, 'Lunch'),
(18, 0, 'Mix veg', '', 40, '1721106840_mix veg.jpg', 1, 'Lunch'),
(19, 0, 'Naan', '', 10, '1721106900_nan roti.jpg', 1, 'Dinner'),
(20, 0, 'Paneer Curry', '', 50, '1721107020_paneer curry.jpg', 1, 'Dinner'),
(21, 0, 'Mix veg', '', 40, '1721107140_mix veg for roti.jpg', 1, 'Dinner'),
(22, 0, 'Roti', '', 5, '1721107260_roti.jpg', 1, 'Dinner'),
(23, 0, 'Chole bhature', '', 30, '1721107380_chole bhature.jpg', 1, 'Breakfast'),
(24, 0, 'Coffee', '', 30, '1721107500_coffee.jpg', 1, 'Liquid Lounge'),
(25, 0, 'Cold Coffee', '', 40, '1721107560_cold coffee.jpg', 1, 'Liquid Lounge'),
(26, 0, 'Tea', '', 10, '1721107620_tea.jpg', 1, 'Liquid Lounge'),
(27, 0, 'Veg Roll', '', 40, '1721235300_Veg Roll.jpg', 1, 'Breakfast');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Meal Master', 'mealmaster@gmail.com', '8092329205', '1600654680_photo-1504674900247-0877df9cc836.jpg', '&lt;h4&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; Welcome to Canteen Master Meal!&lt;/h4&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;&lt;p&gt;At Canteen Master Meal, we believe that every meal should be a delightful experience. Our carefully curated menu offers a variety of delicious and nutritious options to cater to all tastes and preferences. Whether you&amp;#x2019;re in the mood for a hearty breakfast, a light lunch, or a satisfying dinner, we&amp;#x2019;ve got you covered.&lt;br&gt;&lt;/p&gt;&lt;h6 style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;Experience the best of canteen dining with Canteen Master Meal. Whether you&amp;#x2019;re dining in or taking out, we promise a meal that&amp;#x2019;s both satisfying and delicious. Visit us today and make your mealtime a moment to savor.&lt;br&gt;&lt;/h6&gt;&lt;h6 style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;br&gt;&lt;/h6&gt;&lt;h6 style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;Join Us Today!&lt;br&gt;&lt;/h6&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;/p&gt;&lt;h2 style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;br&gt;&lt;/h2&gt;&lt;p&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=admin , 2 = staff'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'Administrator', 'admin', 'admin123', 1),
(2, 'Manager', 'Priti', 'food', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address`) VALUES
(6, 'PRITI', 'KUMARI', 'pritiroy611@gmail.com', '8d777f385d3dfec8815d20f7496026dc', '8092329205', 'Jamshedpur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
