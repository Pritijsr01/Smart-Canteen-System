<?php include('admin/db_connect.php'); ?>

<div class="container-fluid menu-container">
    <div class="col-lg-12">
        <div class="row">
            <!-- Menu Items Panel -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <div class="btn-group mb-3">
                            <button class="btn btn-primary category-toggle" data-category="all">All</button>
                            <button class="btn btn-secondary category-toggle" data-category="Breakfast">Breakfast</button>
                            <button class="btn btn-secondary category-toggle" data-category="Lunch">Lunch</button>
                            <button class="btn btn-secondary category-toggle" data-category="Dinner">Dinner</button>
                            <button class="btn btn-secondary category-toggle" data-category="Liquid Lounge">Liquid Lounge</button>
                        </div>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Img</th>
                                    <th class="text-center">Description</th>
                                    <th class="text-center">Category</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1;
                                $cats = $conn->query("SELECT * FROM product_list order by id asc");
                                while($row=$cats->fetch_assoc()):
                                ?>
                                <tr class="menu-item" data-category="<?php echo $row['category'] ?>">
                                    <td class="text-center"><?php echo $i++ ?></td>
                                    <td class="text-center">
                                        <img src="<?php echo isset($row['img_path']) ? 'assets/img/'.$row['img_path'] :'' ?>" alt="" class="cimg">
                                    </td>
                                    <td class="">
                                        <p>Name : <b><?php echo $row['name'] ?></b></p>
                                        <p>Description : <b class="truncate"><?php echo $row['description'] ?></b></p>
                                        <p>Price : <b>₹<?php echo number_format($row['price'], 2) ?></b></p>
                                    </td>
                                    <td class="text-center"><?php echo $row['category'] ?></td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-success add_to_cart" type="button" data-id="<?php echo $row['id'] ?>" data-name="<?php echo $row['name'] ?>" data-price="<?php echo $row['price'] ?>">Add to Cart</button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
        <!-- Cart Section -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        Cart
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Item</th>
                                    <th class="text-center">Price</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-center">Total</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="cart-items">
                                <!-- Cart items will be appended here by JavaScript -->
                            </tbody>
                        </table>
                        <div class="text-right">
                            <h4>Total: ₹<span id="cart-total">0.00</span></h4>
                            <div class="text-center">
                                <button class="btn btn-block btn-outline-primary" type="button" id="checkout">Proceed to Checkout</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Cart Section -->
        </div>    
    </div>
</div>

<style>
    .menu-container {
        margin-top: 80px; /* Adjust this value according to the height of your navbar */
    }
    img#cimg, .cimg {
        max-height: 10vh;
        max-width: 6vw;
    }
    td {
        vertical-align: middle !important;
    }
    td p {
        margin: unset !important;
    }
    .custom-switch, .custom-control-input, .custom-control-label {
        cursor: pointer;
    }
    b.truncate {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 3; 
        -webkit-box-orient: vertical;    
        font-size: small;
        color: #000000cf;
        font-style: italic;
    }
</style>

<script>
    function displayImg(input, _this) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#cimg').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('#manage-menu').submit(function(e){
        e.preventDefault();
        start_load();
        $.ajax({
            url: 'ajax.php?action=save_menu',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success: function(resp){
                if (resp == 1) {
                    alert_toast("Data successfully added", 'success');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                } else if (resp == 2) {
                    alert_toast("Data successfully updated", 'success');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                }
            }
        });
    });

    $('.category-toggle').click(function(){
        var category = $(this).data('category');
        $('.category-toggle').removeClass('btn-primary').addClass('btn-secondary');
        $(this).removeClass('btn-secondary').addClass('btn-primary');
        if (category == 'all') {
            $('.menu-item').show();
        } else {
            $('.menu-item').each(function(){
                if ($(this).data('category') == category) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    });
    
    $('#qty-minus').click(function(){
        var qty = $('input[name="qty"]').val();
        if(qty == 1){
            return false;
        }else{
            $('input[name="qty"]').val(parseInt(qty) -1);
        }
    })
    $('#qty-plus').click(function(){
        var qty = $('input[name="qty"]').val();
        $('input[name="qty"]').val(parseInt(qty) +1);
    })
    
    $('.add_to_cart').click(function(){
        var id = $(this).data('id');
        var name = $(this).data('name');
        var price = $(this).data('price');
        var exists = false;
        $('#cart-items tr').each(function(){
            if ($(this).data('id') == id) {
                var qty = $(this).find('.cart-qty').val();
                $(this).find('.cart-qty').val(parseInt(qty) + 1);
                exists = true;
                updateCartTotal();
            }
        });
        if (!exists) {
            var item = `
                <tr data-id="${id}">
                    <td class="text-center">${id}</td>
                    <td>${name}</td>
                    <td class="text-right">₹<span class="cart-price">${price}</span></td>
                    <td class="text-center"><input type="number" class="form-control text-center cart-qty" value="1" min="1"></td>
                    <td class="text-right">₹<span class="cart-total">${price}</span></td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-danger remove_from_cart" type="button">Remove</button>
                    </td>
                </tr>
            `;
            $('#cart-items').append(item);
            updateCartTotal();
        }
    });

    $('#cart-items').on('click', '.remove_from_cart', function(){
        $(this).closest('tr').remove();
        updateCartTotal();
    });

    $('#cart-items').on('input', '.cart-qty', function(){
        var qty = $(this).val();
        var price = $(this).closest('tr').find('.cart-price').text();
        var total = parseFloat(price) * parseInt(qty);
        $(this).closest('tr').find('.cart-total').text(total.toFixed(2));
        updateCartTotal();
    });

    function updateCartTotal(){
        var total = 0;
        $('#cart-items tr').each(function(){
            var itemTotal = $(this).find('.cart-total').text();
            total += parseFloat(itemTotal);
        });
        $('#cart-total').text(total.toFixed(2));
    }

    $('#checkout').click(function(){
        if('<?php echo isset($_SESSION['login_user_id']) ?>' == 1){
            location.replace("index.php?page=checkout")
        } else {
            uni_modal("Checkout","login.php?page=checkout")
        }
    })
    
    $('#place-order').click(function(){
        var orderItems = [];
        $('#cart-items tr').each(function(){
            var id = $(this).data('id');
            var quantity = $(this).find('.cart-qty').val();
            orderItems.push({ id: id, quantity: quantity });
        });
        $.ajax({
            url: 'ajax.php?action=place_order',
            method: 'POST',
            data: { items: orderItems },
            success: function(resp){
                if (resp == 1) {
                    alert_toast("Order placed successfully", 'success');
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                } else {
                    alert_toast("Failed to place order", 'danger');
                }
            }
        });
    });
</script>
